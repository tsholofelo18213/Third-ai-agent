package com.example.phoneagent

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LlmClient(private val provider: Provider, private val apiKey: String, private val model: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    companion object {
        val SYSTEM = """
You control an Android phone for the user. Each turn you get the task, your previous actions, and the current screen as a numbered list of UI elements.
Reply with ONLY one JSON object, no other text:
{"action": "tap|type|scroll|back|home|open_app|wait|done",
 "index": <element number for tap/type/scroll, optional for scroll>,
 "text": <text to type, or app name for open_app>,
 "submit": <true to press enter after typing>,
 "direction": "up|down",
 "risky": <true if this action sends a message/email, pays, posts, deletes, books, or is otherwise hard to undo>,
 "say": <short plain-language description of what you are doing; for done, the result for the user>}
Rules: one action per turn. Use open_app to launch apps. Set risky=true BEFORE any irreversible action so the user can approve it. If the screen doesn't change after an action, try something different. When the task is complete or impossible, use done.
""".trimIndent()
    }

    fun next(task: String, history: List<String>, screen: String): JSONObject {
        val prompt = "Task: $task\n\nActions so far:\n" +
            history.takeLast(12).joinToString("\n").ifBlank { "(none)" } +
            "\n\nCurrent screen:\n$screen"
        val text = if (provider.anthropicFormat) callClaude(prompt) else callOpenAiStyle(prompt)
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) error("Model did not return JSON: ${text.take(120)}")
        return JSONObject(text.substring(a, b + 1))
    }

    private fun callClaude(prompt: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 400)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val req = Request.Builder().url(provider.url)
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return send(req) { JSONObject(it).getJSONArray("content").getJSONObject(0).getString("text") }
    }

    private fun callOpenAiStyle(prompt: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4000)
            .put("temperature", 0)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM))
                .put(JSONObject().put("role", "user").put("content", prompt)))
        if (provider.jsonMode) body.put("response_format", JSONObject().put("type", "json_object"))
        val req = Request.Builder().url(provider.url)
            .header("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return send(req) {
            JSONObject(it).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
        }
    }

    private fun send(req: Request, parse: (String) -> String): String {
        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("${provider.label} ${r.code}: ${s.take(200)}")
            return parse(s)
        }
    }
}
