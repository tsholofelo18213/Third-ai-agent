package com.example.phoneagent

/** Apps and screens the agent must never read or act on. Matching is by lowercase substring. */
object Blocklist {
    // South African banks (registered banks, mutual banks, co-operative banks, foreign branches)
    // and well-known bank brands and payment/crypto apps used there.
    private val southAfrica = listOf(
        "absa", "african bank", "africanbank", "bidvest", "capitec", "discovery bank", "discoverybank",
        "firstrand", "fnb", "rmb", "wesbank", "investec", "nedbank", "standard bank", "standardbank",
        "stanbic", "sasfin", "tymebank", "tyme bank", "ubank", "grindrod", "albaraka", "habib", "hbz",
        "bank zero", "bankzero", "finbond", "gbs mutual", "ywbn", "ditsobotla", "ziphakamise",
        "osk koop", "ksk koop", "gig co-op", "access bank", "mercantile", "postbank",
        "citibank", "hsbc", "jpmorgan", "jp morgan", "deutsche", "goldman", "standard chartered",
        "state bank of india", "bank of china", "bank of taiwan", "bank of communications",
        "construction bank", "snapscan", "zapper", "ozow", "vodapay", "shyft", "payfast", "stitch",
        "luno", "valr", "altcoin", "ovex", "mukuru", "ewallet", "nedbank money", "capitec pay", "payshap"
    )

    // Matched against the app's package name and its visible label.
    val appTerms = listOf(
        "bank", "wallet", "pay", "paypal", "venmo", "cash app", "squareup.cash", "zelle",
        "revolut", "transferwise", "mpesa", "m-pesa", "momo", "paytm", "phonepe", "gpay",
        "crypto", "binance", "coinbase", "kraken", "bybit", "metamask", "trust wallet",
        "metatrader", "metaquotes", "mt4", "mt5", "forex", "trading", "broker", "invest",
        "authenticator", "authy", "password", "bitwarden", "lastpass", "1password",
        "onepassword", "agilebits", "dashlane", "keepass"
    ) + southAfrica

    // Matched against what is currently on screen, to catch bank sites inside a browser.
    val screenTerms = listOf(
        "online banking", "internet banking", "mobile banking", "net banking",
        "paypal", "binance", "coinbase", "metatrader", "enter your pin", "card number", "cvv"
    ) + southAfrica

    private fun extraTerms(extra: String) =
        extra.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun appBlocked(pkg: String, label: String, extra: String): Boolean {
        val hay = "$pkg $label".lowercase()
        return appTerms.any { hay.contains(it) } || extraTerms(extra).any { hay.contains(it) }
    }

    fun screenBlocked(text: String, extra: String): Boolean {
        val hay = text.lowercase()
        return screenTerms.any { hay.contains(it) } || extraTerms(extra).any { hay.contains(it) }
    }
}
